import httpx
from app.config import settings  # 👈 IMPORTANTE: Agregamos el import de settings
from app.providers.base import BaseThreatProvider

TIMEOUT = httpx.Timeout(10.0)

class URLHausProvider(BaseThreatProvider):
    name = "urlhaus"
    BASE_URL = "https://urlhaus-api.abuse.ch/v1"

    async def check_url(self, url: str) -> dict:
        # 👈 Inyectamos la cabecera de autenticación obligatoria usando tu .env
        headers = {"Auth-Key": settings.urlhaus_api_key}
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                r = await client.post(f"{self.BASE_URL}/url/", data={"url": url}, headers=headers)
                r.raise_for_status()
                data = r.json()
                
                return {
                    "source": self.name,
                    "supported": True,
                    "query_status": data.get("query_status"),
                    "threat": data.get("threat"),
                    "url_status": data.get("url_status"),
                    "tags": data.get("tags", []),
                }
        except Exception as e:
            return {"source": self.name, "supported": True, "error": str(e)}

    async def check_hash(self, sha256: str) -> dict:
        headers = {"Auth-Key": settings.urlhaus_api_key}
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                r = await client.post(f"{self.BASE_URL}/payload/", data={"sha256_hash": sha256}, headers=headers)
                r.raise_for_status()
                data = r.json()
                
                # Extraemos de forma segura el porcentaje de VirusTotal si existe
                vt_data = data.get("virustotal", {})
                vt_percent = vt_data.get("percent") if isinstance(vt_data, dict) else None
                
                return {
                    "source": self.name,
                    "supported": True,
                    "query_status": data.get("query_status"),
                    "file_type": data.get("file_type"),
                    "signature": data.get("signature"),
                    "virustotal_percent": vt_percent,
                }
        except Exception as e:
            return {"source": self.name, "supported": True, "error": str(e)}

    async def check_ip(self, ip: str) -> dict:
        headers = {"Auth-Key": settings.urlhaus_api_key}
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                # El endpoint /host/ sirve tanto para IPs como para nombres de dominio
                r = await client.post(f"{self.BASE_URL}/host/", data={"host": ip}, headers=headers)
                r.raise_for_status()
                data = r.json()
                
                # Corrección de lógica segura para contar las URLs maliciosas reportadas
                urls_list = data.get("urls", [])
                url_count = len(urls_list) if urls_list else 0
                
                return {
                    "source": self.name,
                    "supported": True,
                    "query_status": data.get("query_status"),
                    "url_count": url_count,
                }
        except Exception as e:
            return {"source": self.name, "supported": True, "error": str(e)}

    async def check_domain(self, domain: str) -> dict:
        # Reutilizamos el endpoint /host/ que maneja perfectamente los dominios directos
        return await self.check_ip(domain)