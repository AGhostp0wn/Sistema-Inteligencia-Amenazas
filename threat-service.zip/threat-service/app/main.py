from fastapi import FastAPI
from app.routers import ip, domain, url, hash

app = FastAPI(title="ThreatGuard AI - Threat Service", version="1.0.0")

app.include_router(ip.router,     prefix="/threat", tags=["IP"])
app.include_router(domain.router, prefix="/threat", tags=["Domain"])
app.include_router(url.router,    prefix="/threat", tags=["URL"])
app.include_router(hash.router,   prefix="/threat", tags=["Hash"])

@app.get("/health")
async def health():
    return {"status": "ok"}