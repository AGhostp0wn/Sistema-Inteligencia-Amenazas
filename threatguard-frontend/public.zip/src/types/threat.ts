export interface ThreatResponse {
  ioc_type: string;
  ioc_value: string;
  risk_score: number;
  classification: string;
  from_cache: boolean;
  sources: any[];
}