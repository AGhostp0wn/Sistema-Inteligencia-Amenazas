import api from "./axios";

export const searchIp =
(ip:string)=>
  api.get(
    `/api/threat/ip/${ip}`
  );

export const searchDomain =
(domain:string)=>
  api.get(
    `/api/threat/domain/${domain}`
  );

export const searchUrl =
(url:string)=>
  api.get(
    `/api/threat/url/${url}`
  );

export const searchHash =
(hash:string)=>
  api.get(
    `/api/threat/hash/${hash}`
  );