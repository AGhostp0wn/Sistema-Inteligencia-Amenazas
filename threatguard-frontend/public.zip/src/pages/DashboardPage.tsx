export default function DashboardPage(){

 return(

  <div className="p-8">

   <h1 className="text-4xl">
    ThreatGuard
   </h1>

  </div>

 );
}