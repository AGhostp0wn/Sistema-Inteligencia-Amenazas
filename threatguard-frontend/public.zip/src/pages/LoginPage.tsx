import { useState } from "react";
import { loginUser } from "../api/auth.api";
import { useAuthStore } from "../store/auth.store";
import { useNavigate } from "react-router-dom";

export default function LoginPage(){

 const [email,setEmail]=
 useState("");

 const [password,setPassword]=
 useState("");

 const setToken =
 useAuthStore(
   state=>state.setToken
 );

 const navigate =
 useNavigate();

 const submit = async(
  e:any
 )=>{

  e.preventDefault();

  const response =
  await loginUser({
   email,
   password
  });

  setToken(
   response.data.token
  );

  navigate("/dashboard");
 };

 return(
  <div className="h-screen flex justify-center items-center">

   <form
    onSubmit={submit}
    className="w-96 p-8 border rounded"
   >

    <h2>
      Login
    </h2>

    <input
      className="border p-2 w-full mt-4"
      placeholder="email"
      onChange={(e)=>
      setEmail(e.target.value)}
    />

    <input
      className="border p-2 w-full mt-4"
      type="password"
      placeholder="password"
      onChange={(e)=>
      setPassword(e.target.value)}
    />

    <button
      className="w-full p-2 mt-4 bg-blue-600 text-white"
    >
      Login
    </button>

   </form>

  </div>
 );
}